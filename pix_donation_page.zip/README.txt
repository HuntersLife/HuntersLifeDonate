Coloca il file index.html e il QR code 'qr-pix.png' nella stessa cartella del tuo repository GitHub.
Poi abilita GitHub Pages (Settings > Pages > Deploy from Branch) per pubblicare la tua pagina.